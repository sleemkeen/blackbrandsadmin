$(document).ready(function () {
    //initialize the javascript
    App.init();
    App.dashboard();
});
